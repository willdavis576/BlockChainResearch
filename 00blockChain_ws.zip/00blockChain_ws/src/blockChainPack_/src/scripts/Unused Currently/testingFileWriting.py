




def main():
    file = open("blockChain.txt", "w")
    file.write("\nasdkadadasdsk")
    file.close()





if __name__ == '__main__':
    main()
